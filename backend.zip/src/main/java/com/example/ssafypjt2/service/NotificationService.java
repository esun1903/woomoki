package com.example.ssafypjt2.service;

import org.springframework.stereotype.Service;

@Service
public interface NotificationService {
   
	
}
