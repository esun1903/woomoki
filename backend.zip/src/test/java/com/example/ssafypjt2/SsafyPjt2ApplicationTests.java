package com.example.ssafypjt2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsafyPjt2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
